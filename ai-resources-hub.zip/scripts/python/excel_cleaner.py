import pandas as pd
df=pd.read_excel("file.xlsx")
df=df.dropna()
df.to_excel("cleaned.xlsx",index=False)
print("Done!")
